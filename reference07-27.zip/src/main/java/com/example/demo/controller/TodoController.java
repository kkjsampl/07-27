package com.example.demo.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.ui.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.vo.*;

@Controller
public class TodoController {
	@Autowired
	private TodoDao todoDao;
	
	@GetMapping({"/","/list"})
	public String list(Model model) {
		List<Todo> todos = todoDao.findAll();
		model.addAttribute("todos", todos);
		return "list";
	}
	
	@GetMapping("/write")
	public String write() {
		return "write";
	}
	
	@PostMapping("/write")
	public String write(String job) {
		todoDao.insert(job);
		return "redirect:/list";
	}
	
	@PostMapping("/update")
	public String update(Integer tno) {
		todoDao.update(tno);
		return "redirect:/list";
	}
	
	@PostMapping("/delete")
	public String delete(Integer tno) {
		todoDao.delete(tno);
		return "redirect:/list";
	}
}
