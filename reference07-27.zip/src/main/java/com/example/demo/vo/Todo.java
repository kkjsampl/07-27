package com.example.demo.vo;

import java.time.*;

import lombok.*;

@Getter
@AllArgsConstructor
public class Todo {
	private Long tno;
	private String job;
	private LocalDate writeday;
	@Setter
	private Boolean finish; 
}
