package com.example.demo.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.vo.*;

@Mapper
public interface TodoDao {
	@Select("select * from todos order by tno desc")
	public List<Todo> findAll();
	
	@Insert("insert into todos(tno, job, writeday, finish) values(todos_seq.nextval, #{job}, sysdate, 0)")
	public Integer insert(String job);
	
	@Update("update todos set finish=abs(finish-1) where tno=#{tno}")
	public Integer update(Integer tno);
	
	@Delete("delete todos where tno=#{tno}")
	public Integer delete(Integer tno);
}
