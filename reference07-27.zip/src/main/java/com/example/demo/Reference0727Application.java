package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reference0727Application {

	public static void main(String[] args) {
		SpringApplication.run(Reference0727Application.class, args);
	}

}
